class BotError extends Error {}

module.exports = {
  BotError,
};
